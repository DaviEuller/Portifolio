from tkinter import * 
from tkinter import ttk 
import sqlite3
from tkinter import messagebox
import os
janela = Tk()
janela.geometry("1200x720")
janela.title("ADAE")
janela.configure(background="#2F2F2F")
def segunda_tela():
    for widget in janela.winfo_children():
        widget.destroy()


    from datetime import datetime, date

    def sistema_de_dias(conta_id):
        dia_limite = 7
        dia_atual = datetime.now().date()

        conn = sqlite3.connect("dados_relogio.db")
        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS relogio (
        conta_id TEXT,
        ultimo_dia TEXT
        );
        """)

        cursor.execute("SELECT ultimo_dia FROM relogio WHERE conta_id = ?", (conta_id,))
        registro = cursor.fetchone()

        if registro is None:
            cursor.execute("INSERT INTO relogio (conta_id, ultimo_dia) VALUES (?, ?)", (conta_id, str(dia_atual)))
        else:
            ultima_data_registrada = datetime.strptime(registro[0], "%Y-%m-%d").date()


            cursor.execute("UPDATE relogio SET ultimo_dia = ? WHERE conta_id = ?", (str(dia_atual), conta_id))

            diff = dia_atual - ultima_data_registrada
            dias_passados = diff.days

            if dias_passados > dia_limite:

                print("Limite de dias ultrapassado!")

        conn.commit()
        conn.close()

    def obter_bancos_dados():
        global bancos_dados
        bancos_dados = []

        for arquivo in os.listdir():
            if arquivo.endswith(".db"):
                bancos_dados.append(arquivo)

        # Remover as tabelas específicas
        tabelas_remover = ["Contas.db", "dados_relogio.db", "Sistema_de_pontos.db"]
        for tabela in tabelas_remover:
            if tabela in bancos_dados:
                bancos_dados.remove(tabela)




    sistema_de_dias(emaill)
    obter_bancos_dados()
    text_combobox_tabela_extração = Label(janela, text="Escolher Quiz", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
    text_combobox_tabela_extração.place(x=50, y=30)

    global combobox_tabela_extração
    combobox_tabela_extração = ttk.Combobox(janela, values=bancos_dados)
    combobox_tabela_extração.configure(state="readonly")
    combobox_tabela_extração.place(x=50, y=60)

    def montar_quiz():
        Quiz_tabela = combobox_tabela_extração.get()
        conn = sqlite3.connect(Quiz_tabela)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        Contar_tabelas = cursor.fetchall()

        combobox_tabela = ttk.Combobox(janela, values=Contar_tabelas)
        combobox_tabela.config(state="readonly")
        combobox_tabela.place(x=850, y=60)

        def montar_alternativas():
            tabela_pergunta  =  combobox_tabela.get()

            conn = sqlite3.connect(Quiz_tabela)
            cursor = conn.cursor()

            cursor.execute(f"SELECT * FROM {tabela_pergunta}")
            pergunta_table =  cursor.fetchone()

            titulo_pergunta  = pergunta_table[0]
            Alternativa_pergunta  = pergunta_table[1]
            opção_1_alternativas_table = pergunta_table[2]
            opção_2_alternativas_table = pergunta_table[3]
            opção_3_alternativas_table = pergunta_table[4]
            opção_4_alternativas_table = pergunta_table[5]
            opção_5_alternativas_table = pergunta_table[6]
            opção_6_alternativas_table = pergunta_table[7]
            resposta_table = pergunta_table[8]

            def pergunta_1_resposta():
                global resposta
                resposta = opção_1_alternativas_table

            def pergunta_2_resposta():
                global resposta
                resposta = opção_2_alternativas_table

            def pergunta_3_resposta():
                global resposta
                resposta = opção_3_alternativas_table

            def pergunta_4_resposta():
                global resposta
                resposta = opção_4_alternativas_table

            def pergunta_5_resposta():
                global resposta
                resposta = opção_5_alternativas_table

            def pergunta_6_resposta():
                global resposta
                resposta = opção_6_alternativas_table

            if Alternativa_pergunta == "2":
                titullo_alternativa = Label(janela, text=f"{titulo_pergunta}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
                titullo_alternativa.place(x=60, y=120)

                opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_1_resposta)
                opção1_button.place(x=50, y=200)

                opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_2_resposta)
                opção2_button.place(x=50, y=260)


            elif Alternativa_pergunta == "3":
                titullo_alternativa = Label(janela, text=f"{titulo_pergunta}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
                titullo_alternativa.place(x=60, y=120)

                opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_1_resposta)
                opção1_button.place(x=50, y=200)

                opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_2_resposta)
                opção2_button.place(x=50, y=260)

                opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_3_resposta)
                opção3_button.place(x=50, y=320)
            elif Alternativa_pergunta == "4":
                titullo_alternativa = Label(janela, text=f"{titulo_pergunta}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
                titullo_alternativa.place(x=60, y=120)

                opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_1_resposta)
                opção1_button.place(x=50, y=200)

                opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_2_resposta)
                opção2_button.place(x=50, y=260)

                opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_3_resposta)
                opção3_button.place(x=50, y=320)

                opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_4_resposta)
                opção4_button.place(x=50, y=380)
            elif Alternativa_pergunta == "5":
                titullo_alternativa = Label(janela, text=f"{titulo_pergunta}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
                titullo_alternativa.place(x=60, y=120)

                opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_1_resposta)
                opção1_button.place(x=50, y=200)

                opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_2_resposta)
                opção2_button.place(x=50, y=260)

                opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_3_resposta)
                opção3_button.place(x=50, y=320)

                opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_4_resposta)
                opção4_button.place(x=50, y=380)

                opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_5_resposta)
                opção5_button.place(x=50, y=440)
            elif Alternativa_pergunta == "6":
                titullo_alternativa = Label(janela, text=f"{titulo_pergunta}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
                titullo_alternativa.place(x=60, y=120)

                opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_1_resposta)
                opção1_button.place(x=50, y=200)

                opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_2_resposta)
                opção2_button.place(x=50, y=260)

                opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_3_resposta)
                opção3_button.place(x=50, y=320)

                opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_4_resposta)
                opção4_button.place(x=50, y=380)

                opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_5_resposta)
                opção5_button.place(x=50, y=440)

                opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=pergunta_6_resposta)
                opção6_button.place(x=50, y=500)

            def verificar_resposta():
                if Alternativa_pergunta == "2":
                    if resposta_table == opção_1_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)
                    elif resposta_table == opção_2_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)
                elif Alternativa_pergunta == "3":
                    if resposta_table == opção_1_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)
                    elif resposta_table == opção_2_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)
                    elif resposta_table == opção_3_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)
                elif Alternativa_pergunta == "4":
                    if resposta_table == opção_1_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)
                    elif resposta_table == opção_2_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)
                    elif resposta_table == opção_3_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)
                    elif resposta_table == opção_4_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)
                elif Alternativa_pergunta == "5":
                    if resposta_table == opção_1_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)
                    elif resposta_table == opção_2_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)
                    elif resposta_table == opção_3_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)
                    elif resposta_table == opção_4_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)
                    elif resposta_table == opção_5_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)
                elif Alternativa_pergunta == "6":
                    if resposta_table == opção_1_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                    elif resposta_table == opção_2_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                    elif resposta_table == opção_3_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                    elif resposta_table == opção_4_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                    elif resposta_table == opção_5_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                    elif resposta_table == opção_6_alternativas_table:
                        opção1_button = Button(janela, text=f"{opção_1_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção1_button.place(x=50, y=200)
                        
                        opção2_button = Button(janela, text=f"{opção_2_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção2_button.place(x=50, y=260)

                        opção3_button = Button(janela, text=f"{opção_3_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção3_button.place(x=50, y=320)

                        opção4_button = Button(janela, text=f"{opção_4_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção4_button.place(x=50, y=380)

                        opção5_button = Button(janela, text=f"{opção_5_alternativas_table}", font="Arial 16 bold", bg="#FF0000", fg="#ffffff")
                        opção5_button.place(x=50, y=440)

                        opção6_button = Button(janela, text=f"{opção_6_alternativas_table}", font="Arial 16 bold", bg="#008000", fg="#ffffff")
                        opção6_button.place(x=50, y=500)
                if resposta == resposta_table:
                    conn = sqlite3.connect("Sistema_de_pontos.db")
                    cursor = conn.cursor()

                    cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Pontos(
                    Conta TEXT
                    Pontos TEXT
                    );
                    """)
                    print('Acertou')
                else:
                    conn = sqlite3.connect("Sistema_de_pontos.db")
                    cursor = conn.cursor()

                    cursor.execute("""
                    CREATE TABLE IF NOT EXISTS Pontos(
                    Conta TEXT
                    Pontos TEXT
                    );
                    """)
                    print('errou')

            botão_verificar = Button(janela, text="verificar resposta", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=verificar_resposta)
            botão_verificar.place(x=1000, y=600)
        botão_resposta = Button(janela, text="ir para a pergunta", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=montar_alternativas)
        botão_resposta.place(x=1000, y=60)
        

    botão_motar_quiz = Button(janela, text="Começar", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=montar_quiz)
    botão_motar_quiz.place(x=200, y=65)


def Setup_Login():
    Email_text_entry = Label(janela, text="Login", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
    Email_text_entry.place(x=50, y=30)

    global Email_Entry
    Email_Entry = Entry(janela, width=45)
    Email_Entry.place(x=130, y=35)

    Senha_text_entry = Label(janela, text="Senha", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
    Senha_text_entry.place(x=50, y=70)

    Senha_Entry = Entry(janela, width=45)
    Senha_Entry.place(x=130, y=75)

    def resgistrar():
        conn = sqlite3.connect("Contas.db")
        cursor = conn.cursor()
        
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS contas (
        Nome TEXT,
        Email TEXT,
        Senha TEXT
        );
        """)


        Email_text_entry.place(x=50, y=70)
        Email_Entry.place(x=130, y=75)
        Senha_text_entry.place(x=50, y=110)
        Senha_Entry.place(x=130, y=115)
        botão_Login.place(x=9999)
        botão_resgistrar.place(x=9999)

        Nome_text_entry = Label(janela, text="Nome:", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff")
        Nome_text_entry.place(x=50, y=30)
    
        Nome_entry = Entry(janela, width=45)
        Nome_entry.place(x=130, y=35)

        def Registrar_no_banco():
            email = Email_Entry.get()
            Senha = Senha_Entry.get()
            Nome = Nome_entry.get()
            conn = sqlite3.connect("Contas.db")
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM contas WHERE Email = ? OR Senha = ? OR Nome = ?", (email, Senha, Nome))
            verificacao = cursor.fetchall()
            if email == "" or Senha == "" or Nome == "":
                messagebox.showerror(title="Falta de dados", message="Complete todos os campos")
            elif verificacao:
                messagebox.showerror(title="Contas", message="Conta existente")
            else:
                cursor.execute("INSERT INTO contas (Nome, Email, Senha) VALUES (?, ?, ?)", (Nome, email, Senha))
                conn.commit()


        botão_resgistrar_2 = Button(janela, text="Registrar", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=Registrar_no_banco)
        botão_resgistrar_2.place(x=50, y=160)
        def Back():
            Email_text_entry.place(x=50, y=30)
            Email_Entry.place(x=130, y=35)
            Senha_text_entry.place(x=50, y=70)
            Senha_Entry.place(x=130, y=75)
            Nome_text_entry.place(x=5000)
            Nome_entry.place(x=5000)
            Botão_Back.place(x=1700)
            botão_resgistrar_2.place(x=5000)
            botão_Login.place(x=50, y=140)
            botão_resgistrar.place(x=200, y=140)

        Botão_Back = Button(janela, text="Back", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=Back)
        Botão_Back.place(x=170, y=160)

    def Login():
        conn = sqlite3.connect("Contas.db")
        cursor = conn.cursor()
        global emaill
        emaill = Email_Entry.get()
        Senha = Senha_Entry.get()

        cursor.execute("SELECT * FROM contas WHERE Email = ? and Senha = ?", (emaill, Senha))
        vericação = cursor.fetchone()

        
            
        if (emaill in vericação and Senha in vericação):
            segunda_tela()
        else:
            messagebox.showerror(title="erro", message="senha ou login invalido")
        
    botão_Login = Button(janela, text="Login", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=Login)
    botão_Login.place(x=50, y=140)

    botão_resgistrar = Button(janela, text="Registrar", font="Arial 16 bold", bg="#2F2F2F", fg="#ffffff", command=resgistrar)
    botão_resgistrar.place(x=200, y=140)
Setup_Login()
janela.mainloop()