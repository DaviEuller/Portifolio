from tkinter import *
from tkinter import ttk
import sqlite3
import os
from tkinter import messagebox

janela = Tk()
janela.geometry("1200x720")
janela.resizable(False, False)
janela.configure(background="#2F2F2F")
janela.title("Criar Quiz")
def novo_titulo():
    conn = sqlite3.connect("Dados_perguntas.db")
    conn.close()
    Nome_banco_de_dados_text = Label(janela, text="Titulo", font="Arial 16 bold", fg="#ffffff", bg="#2F2F2F")
    Nome_banco_de_dados_text.place(x=50, y=65)

    Nome_banco_de_dados = Entry(janela, width=45)
    Nome_banco_de_dados.place(x=130, y=70)

    def trocar_titulo():
        Novo_TITULO = Nome_banco_de_dados.get()
        global novo_titulo1
        novo_titulo1 = Novo_TITULO + ".db"
        os.rename("Dados_perguntas.db", novo_titulo1)

    botão_de_renomear = Button(janela, width=20, text="Nomear", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=trocar_titulo)
    botão_de_renomear.place(x=300, y=110)

def num_perguntas():
    combobox_num_perguntas_text = Label(janela, text="Numero de perguntas", font="Arial 16 bold", fg="#ffffff", bg="#2F2F2F")
    combobox_num_perguntas_text.place(x=50, y=250)

    combobox_num_perguntas = ttk.Combobox(janela, values=[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30])
    combobox_num_perguntas.place(x=50, y=300)
    combobox_num_perguntas.configure(state="readonly")
    def add_perguntas():
        combobox_num_perguntas_get = int(combobox_num_perguntas.get())

        for num_pergunta in range(1, combobox_num_perguntas_get + 1):
            conn = sqlite3.connect(novo_titulo1)
            cursor = conn.cursor()
            cursor.execute(f"""
                CREATE TABLE Pergunta_{num_pergunta} (
                    Titulo TEXT DEFAULT NULL,
                    Alternativas TEXT DEFAULT 0,
                    Opcao1 TEXT DEFAULT NULL,
                    Opcao2 TEXT DEFAULT NULL,
                    Opcao3 TEXT DEFAULT NULL,
                    Opcao4 TEXT DEFAULT NULL,
                    Opcao5 TEXT DEFAULT NULL,
                    Opcao6 TEXT DEFAULT NULL,
                    Resposta_correta TEXT DEFAULT NULL
                )
            """)
            conn.commit()
            conn.close()

    Botaão_aplicar_perguntas = Button(janela, width=20, text="Aplicar", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=add_perguntas)
    Botaão_aplicar_perguntas.place(x=50, y=350)

def ir_para_proxima_janela():
    for widget in janela.winfo_children():
        widget.destroy()

    def achar_perguntas():
        conn = sqlite3.connect(novo_titulo1)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tabelas = cursor.fetchall()

        nomes_tabelas = [tabela[0] for tabela in tabelas]

        combobox_extrair_perguntas_text = Label(janela, text="Perguntas", font="Arial 16 bold", fg="#ffffff", bg="#2F2F2F")
        combobox_extrair_perguntas_text.place(x=50, y=10)
        
        global combobox_extrair_perguntas
        combobox_extrair_perguntas = ttk.Combobox(janela, values=nomes_tabelas)
        combobox_extrair_perguntas.configure(state="readonly")
        combobox_extrair_perguntas.place(x=50, y=40)

        def ver_editar_perguntas():
            combobox_extrair_perguntas_get = combobox_extrair_perguntas.get()

            conn = sqlite3.connect(novo_titulo1)
            cursor = conn.cursor()

            cursor.execute(f"SELECT * FROM {combobox_extrair_perguntas_get}")
            resultados = cursor.fetchall()

            Titulo_Entry_text = Label(janela, text="Titulo da Pergunta", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
            Titulo_Entry_text.place(x=50, y=150)

            titulo_entry = Entry(janela, width=45)
            titulo_entry.place(x=50, y=185)

            num_perguntas_alternativas_combobox_text = Label(janela, text="numero de alternativas", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
            num_perguntas_alternativas_combobox_text.place(x=50, y=200)

            num_perguntas_alternativas_combobox = ttk.Combobox(janela, values=["2", "3", "4", "5", "6"])
            num_perguntas_alternativas_combobox.configure(state="readonly")
            num_perguntas_alternativas_combobox.place(x=50, y=230)
            

            def definir_alternativas():

                num_alternativas = num_perguntas_alternativas_combobox.get()
                if num_alternativas == "2":
                    global Alternativa_1_Entry
                    global Alternativa_2_Entry
                    global alternativa_resposta
                    Alternativa_1_Entry_text = Label(janela, text="Alternativa 1:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_1_Entry_text.place(x=50, y=270)

                    Alternativa_1_Entry = Entry(janela, width=45)
                    Alternativa_1_Entry.place(x=230, y=275)

                    Alternativa_2_Entry_text = Label(janela, text="Alternativa 2:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_2_Entry_text.place(x=50, y=320)

                    Alternativa_2_Entry = Entry(janela, width=45)
                    Alternativa_2_Entry.place(x=230, y=325)

                    alternativa_resposta_text = Label(janela, text="Alternativa correta:",font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    alternativa_resposta_text.place(x=50, y=600)

                    alternativa_resposta = ttk.Combobox(janela, values=["Opção1", "Opção2", "Opção3", "Opção4", "Opção5", "Opção6"])
                    alternativa_resposta.config(state="readonly")
                    alternativa_resposta.place(x=330, y=610)
                elif num_alternativas == "3":
                    global Alternativa_3_Entry
                    Alternativa_1_Entry_text = Label(janela, text="Alternativa 1:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_1_Entry_text.place(x=50, y=270)

                    Alternativa_1_Entry = Entry(janela, width=45)
                    Alternativa_1_Entry.place(x=230, y=275)

                    Alternativa_2_Entry_text = Label(janela, text="Alternativa 2:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_2_Entry_text.place(x=50, y=320)

                    Alternativa_2_Entry = Entry(janela, width=45)
                    Alternativa_2_Entry.place(x=230, y=325)

                    Alternativa_3_Entry_text = Label(janela, text="Alternativa 3:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_3_Entry_text.place(x=50, y=370)

                    Alternativa_3_Entry = Entry(janela, width=45)
                    Alternativa_3_Entry.place(x=230, y=375)

                    alternativa_resposta_text = Label(janela, text="Alternativa correta:",font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    alternativa_resposta_text.place(x=50, y=600)

                    alternativa_resposta = ttk.Combobox(janela, values=["Opção1", "Opção2", "Opção3", "Opção4", "Opção5", "Opção6"])
                    alternativa_resposta.config(state="readonly")
                    alternativa_resposta.place(x=330, y=610)
                elif num_alternativas == "4":
                    global Alternativa_4_Entry
                    Alternativa_1_Entry_text = Label(janela, text="Alternativa 1:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_1_Entry_text.place(x=50, y=270)

                    Alternativa_1_Entry = Entry(janela, width=45)
                    Alternativa_1_Entry.place(x=230, y=275)

                    Alternativa_2_Entry_text = Label(janela, text="Alternativa 2:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_2_Entry_text.place(x=50, y=320)

                    Alternativa_2_Entry = Entry(janela, width=45)
                    Alternativa_2_Entry.place(x=230, y=325)

                    Alternativa_3_Entry_text = Label(janela, text="Alternativa 3:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_3_Entry_text.place(x=50, y=370)

                    Alternativa_3_Entry = Entry(janela, width=45)
                    Alternativa_3_Entry.place(x=230, y=375)

                    Alternativa_4_Entry_text = Label(janela, text="Alternativa 4:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_4_Entry_text.place(x=50, y=420)

                    Alternativa_4_Entry = Entry(janela, width=45)
                    Alternativa_4_Entry.place(x=230, y=425)

                    alternativa_resposta_text = Label(janela, text="Alternativa correta:",font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    alternativa_resposta_text.place(x=50, y=600)

                    alternativa_resposta = ttk.Combobox(janela, values=["Opção1", "Opção2", "Opção3", "Opção4", "Opção5", "Opção6"])
                    alternativa_resposta.config(state="readonly")
                    alternativa_resposta.place(x=330, y=610)
                elif num_alternativas == "5":
                    global Alternativa_5_Entry
                    Alternativa_1_Entry_text = Label(janela, text="Alternativa 1:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_1_Entry_text.place(x=50, y=270)

                    Alternativa_1_Entry = Entry(janela, width=45)
                    Alternativa_1_Entry.place(x=230, y=275)

                    Alternativa_2_Entry_text = Label(janela, text="Alternativa 2:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_2_Entry_text.place(x=50, y=320)

                    Alternativa_2_Entry = Entry(janela, width=45)
                    Alternativa_2_Entry.place(x=230, y=325)

                    Alternativa_3_Entry_text = Label(janela, text="Alternativa 3:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_3_Entry_text.place(x=50, y=370)

                    Alternativa_3_Entry = Entry(janela, width=45)
                    Alternativa_3_Entry.place(x=230, y=375)

                    Alternativa_4_Entry_text = Label(janela, text="Alternativa 4:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_4_Entry_text.place(x=50, y=420)

                    Alternativa_4_Entry = Entry(janela, width=45)
                    Alternativa_4_Entry.place(x=230, y=425)

                    Alternativa_5_Entry_text = Label(janela, text="Alternativa 5:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_5_Entry_text.place(x=50, y=470)

                    Alternativa_5_Entry = Entry(janela, width=45)
                    Alternativa_5_Entry.place(x=230, y=475)

                    alternativa_resposta_text = Label(janela, text="Alternativa correta:",font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    alternativa_resposta_text.place(x=50, y=600)

                    alternativa_resposta = ttk.Combobox(janela, values=["Opção1", "Opção2", "Opção3", "Opção4", "Opção5", "Opção6"])
                    alternativa_resposta.config(state="readonly")
                    alternativa_resposta.place(x=330, y=610)
                elif num_alternativas == "6":
                    global Alternativa_6_Entry
                    Alternativa_1_Entry_text = Label(janela, text="Alternativa 1:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_1_Entry_text.place(x=50, y=270)

                    Alternativa_1_Entry = Entry(janela, width=45)
                    Alternativa_1_Entry.place(x=230, y=275)

                    Alternativa_2_Entry_text = Label(janela, text="Alternativa 2:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_2_Entry_text.place(x=50, y=320)

                    Alternativa_2_Entry = Entry(janela, width=45)
                    Alternativa_2_Entry.place(x=230, y=325)

                    Alternativa_3_Entry_text = Label(janela, text="Alternativa 3:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_3_Entry_text.place(x=50, y=370)

                    Alternativa_3_Entry = Entry(janela, width=45)
                    Alternativa_3_Entry.place(x=230, y=375)

                    Alternativa_4_Entry_text = Label(janela, text="Alternativa 4:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_4_Entry_text.place(x=50, y=420)

                    Alternativa_4_Entry = Entry(janela, width=45)
                    Alternativa_4_Entry.place(x=230, y=425)

                    Alternativa_5_Entry_text = Label(janela, text="Alternativa 5:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_5_Entry_text.place(x=50, y=470)

                    Alternativa_5_Entry = Entry(janela, width=45)
                    Alternativa_5_Entry.place(x=230, y=475)

                    Alternativa_6_Entry_text = Label(janela, text="Alternativa 6:", font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    Alternativa_6_Entry_text.place(x=50, y=520)

                    Alternativa_6_Entry = Entry(janela, width=45)
                    Alternativa_6_Entry.place(x=230, y=525)

                    alternativa_resposta_text = Label(janela, text="Alternativa correta:",font="Arial 20 bold", fg="#ffffff", bg="#2F2F2F")
                    alternativa_resposta_text.place(x=50, y=600)

                    alternativa_resposta = ttk.Combobox(janela, values=["Opção1", "Opção2", "Opção3", "Opção4", "Opção5", "Opção6"])
                    alternativa_resposta.config(state="readonly")
                    alternativa_resposta.place(x=330, y=610)
            botão_num_alternativas = Button(janela, width=20, text="Definir", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=definir_alternativas)
            botão_num_alternativas.place(x=500, y=240)
            def salvar_alternativas():
                titulo = titulo_entry.get()
                alternativas = num_perguntas_alternativas_combobox.get()
                if alternativas == "2":
                    opção1 = Alternativa_1_Entry.get()
                    opção2 = Alternativa_2_Entry.get()
                elif alternativas == "3":
                    opção1 = Alternativa_1_Entry.get()
                    opção2 = Alternativa_2_Entry.get()
                    opção3 = Alternativa_3_Entry.get()
                elif alternativas == "4":
                    opção1 = Alternativa_1_Entry.get()
                    opção2 = Alternativa_2_Entry.get()
                    opção3 = Alternativa_3_Entry.get()
                    opção4 = Alternativa_4_Entry.get()
                elif alternativas == "5":
                    opção1 = Alternativa_1_Entry.get()
                    opção2 = Alternativa_2_Entry.get()
                    opção3 = Alternativa_3_Entry.get()
                    opção4 = Alternativa_4_Entry.get()
                    opção5 = Alternativa_5_Entry.get()
                elif alternativas == "6":
                    opção1 = Alternativa_1_Entry.get()
                    opção2 = Alternativa_2_Entry.get()
                    opção3 = Alternativa_3_Entry.get()
                    opção4 = Alternativa_4_Entry.get()
                    opção5 = Alternativa_5_Entry.get()
                    opção6 = Alternativa_6_Entry.get()
                resposta_certa = alternativa_resposta.get()
                if resposta_certa == "Opção1":
                    resposta_certa1 = Alternativa_1_Entry.get()
                elif resposta_certa == "Opção2":
                    resposta_certa1 = Alternativa_2_Entry.get()
                elif resposta_certa == "Opção3":
                    resposta_certa1 = Alternativa_3_Entry.get()
                elif  resposta_certa == "Opção4":
                    resposta_certa1 == Alternativa_4_Entry.get()
                elif resposta_certa == "Opção5":
                    resposta_certa1 = Alternativa_5_Entry.get()
                elif resposta_certa == "Opção6":
                    resposta_certa1 = Alternativa_6_Entry.get()

                conn = sqlite3.connect(novo_titulo1)
                cursor = conn.cursor()
                if alternativas == "2":
                    cursor.execute(f"INSERT INTO {combobox_extrair_perguntas_get} (Titulo, Alternativas, Opcao1, Opcao2, Resposta_correta) VALUES (?, ?, ?, ?, ?)", (titulo, alternativas, opção1, opção2, resposta_certa1))
                    conn.commit()
                elif alternativas == "3":
                    cursor.execute(f"INSERT INTO {combobox_extrair_perguntas_get} (Titulo, Alternativas, Opcao1, Opcao2, Opcao3, Resposta_correta) VALUES (?, ?, ?, ?, ?, ?)", (titulo, alternativas, opção1, opção2, opção3, resposta_certa1))
                    conn.commit()
                elif alternativas == "4":
                    cursor.execute(f"INSERT INTO {combobox_extrair_perguntas_get} (Titulo, Alternativas, Opcao1, Opcao2, Opcao3, Opcao4, Resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?)", (titulo, alternativas, opção1, opção2, opção3, opção4, resposta_certa1))
                    conn.commit()
                elif alternativas == "5":
                    cursor.execute(f"INSERT INTO {combobox_extrair_perguntas_get} (Titulo, Alternativas, Opcao1, Opcao2, Opcao3, Opcao4, Opcao5, Resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (titulo, alternativas, opção1, opção2, opção3, opção4, opção5, resposta_certa1))
                    conn.commit()
                elif alternativas == "6":
                    cursor.execute(f"INSERT INTO {combobox_extrair_perguntas_get} (Titulo, Alternativas, Opcao1, Opcao2, Opcao3, Opcao4, Opcao5, Opcao6, Resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (titulo, alternativas, opção1, opção2, opção3, opção4, opção5, opção6, resposta_certa1))
                    conn.commit()
                messagebox.showinfo(title="ir para proxima janela", message="para editar uma outra pergunta vai em perguntas e mude para qual desejar")
            
            botão_salvar = Button(janela, width=20, text="salvar", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=salvar_alternativas)
            botão_salvar.place(x=700, y=600)
                
        botão_ver_perguntas = Button(janela, width=20, text="Aplicar", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=ver_editar_perguntas)
        botão_ver_perguntas.place(x=200, y=45)

    achar_perguntas()

botão_ir_para_proxima_janela = Button(janela, width=20, text="ir para proxima janela", font="Arial 10 bold", fg="#ffffff", bg="#2F2F2F", command=ir_para_proxima_janela)
botão_ir_para_proxima_janela.place(x=50, y=600)

novo_titulo()
num_perguntas()
janela.mainloop()